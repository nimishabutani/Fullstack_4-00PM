import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div>
      <form>
        <label htmlFor="" className='fw-bold text-danger'>Subject : </label>
        <input type="text" placeholder='Type Your Subject here' /><br></br>
        <label htmlFor="" className='fw-bold text-danger'>Fees</label>
        <input type="text" placeholder='Type Your fees here' />
        <input type="button" value="Submit" />
      </form>
    </div>
  )
}

export default App
